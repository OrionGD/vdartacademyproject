package com.janaeswar.AMS.Repository;

import com.janaeswar.AMS.Model.Agency;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AgencyRepository extends JpaRepository<Agency, Long> {
}
