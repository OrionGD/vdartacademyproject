package com.janaeswar.AMS.Repository;

import com.janaeswar.AMS.Model.Location;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<Location, Long> {
}
