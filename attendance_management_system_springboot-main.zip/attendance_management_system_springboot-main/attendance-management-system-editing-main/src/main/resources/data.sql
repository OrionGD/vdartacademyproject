INSERT INTO employees (company, location, email, name, password, role, approved, department, gender, blood_group, shift)
VALUES ('VDart Technologies Pvt Ltd', 'Trichy', 'admin@vdart.com', 'Admin', 'admin123', 'ADMIN', TRUE, 'HR', 'Female', 'O+', 'Morning');
